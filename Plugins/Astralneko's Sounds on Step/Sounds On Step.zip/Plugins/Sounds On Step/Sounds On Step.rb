#==================================================================================================#
#                                        SOUNDS--ON--STEP
#                                          By Astralneko
#==================================================================================================#
# This simply allows for the capability to have sounds on step.
# 
# To actually use, you'll need to define the step sound effect for the tile in
#   the TerrainTag script section, adding the following line to each terraintag:
# :sound_effect           => ["(filename)",(volume),(pitch)]
#   Replace (filename) with a sound file within the SE folder. For example,
# :sound_effect           => ["StepGrass",100,100]
#   will set the sound effect to StepGrass, which is recommended for tall grass.
# Replace (volume) with the volume as a percent. 100 is full blast.
# Replace (pitch) with the pitch modifier. 100 is the default.
#
# If the sound effect doesn't need its volume or pitch modified, you can simply
#   remove the array brackets (the []) and define it as:
# :sound_effect           => "StepGrass"
#
# You will need to place the sound effect for those tiles in the SE folder,
# and set the tiles that should play that sound to the proper TerrainTag.
# 
# By default, the step sound effect will be the provided sound files:
# - StepWood if indoors
# - StepDefault if outdoors
# Therefore, tiles that should use this sound effect do not need a sound_effect item in TerrainTag.
#==================================================================================================#

#====================================
# Add attr_reader for terrain tag
#====================================
module GameData
	class TerrainTag
		attr_reader :sound_effect
		
		alias initialize initialize_old
		def initialize(hash)
			initialize_old(hash)
			@sound_effect = hash[:sound_effect] || nil
		end
	end
end

#===================================
# Play defined sound effect
#===================================
Events.onStepTaken += proc { |_sender, e|
	event = e[0]   # Get the event affected by field movement
	if $MapFactory.getTerrainTag(event.map.map_id, x, y, true).sound_effect &&
	   $MapFactory.getTerrainTag(event.map.map_id, x, y, true).sound_effect.is_a? Array
		if sound_effect[2]
			pbSEPlay(sound_effect[0],sound_effect[1],sound_effect[2])
		elsif sound_effect[1]
			pbSEPlay(sound_effect[0],sound_effect[1])
		else
			pbSEPlay(sound_effect[0])
		end
	elsif $MapFactory.getTerrainTag(event.map.map_id, x, y, true).sound_effect
		pbSEPlay(sound_effect)
	else
		if GameData::MapMetadata.get($game_map.map_id).outdoor_map
			pbSEPlay("StepDefault")
		else
			pbSEPlay("StepWood")
		end
	end
}